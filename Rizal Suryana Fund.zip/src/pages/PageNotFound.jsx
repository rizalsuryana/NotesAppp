import React from "react";

const PageNotFound = () => {
    return(
        <section>
            <h1>
                404
            </h1>
            <p>Error : Page not found x_x</p>
        </section>
    );
}


export default PageNotFound;